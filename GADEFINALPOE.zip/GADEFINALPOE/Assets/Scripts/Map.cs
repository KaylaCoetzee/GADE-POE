﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace GADEFINALPOE
{
    internal class Map
    {

        string FIELD_SYMBOL = ".";
        private string[,] map = new string[20, 20];
        public MeleeUnit[] mU = new MeleeUnit[50];
        public RangedUnit[] rU = new RangedUnit[50];
        public int numberOfUnitsOnMap = 0;



        public List<Unit> unitsOnMap = new List<Unit>();
        public List<Building> buildingsOnMap = new List<Building>();



        public string unitFaction;

        public void team()
        {
            Random rnd = new Random();
            int factionChoice = rnd.Next(1, 3);

            if (factionChoice == 1)
            {
                unitFaction = "G";
            }
            else if (factionChoice == 2)
            {
                unitFaction = "B";
            }


        }
        public void populate()
        {
            initialiseMap();
        }

        public string initialiseMap()
        {
            string showMap = "";


            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    map[i, j] = ".";

                }
            }

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    showMap += map[i, j];
                }
                showMap += "\n";
            }

            FactoryBuilding f = new FactoryBuilding(4, 16, 100, "Orange", "#");
            
            factoryList.Add(f);
            map[4, 16] = factoryList[0].Symbol;
            buildingsOnMap.Add(f);

            ResourceBuilding rb = new ResourceBuilding(15, 9, 100, "Blue", "$", "Food", 2, 100);
            resourceList.Add(rb);
            map[15, 9] = resourceList[0].Symbol;
            buildingsOnMap.Add(rb);

            return showMap;


        }

        public string redraw()
        {

            string display = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    display += map[i, j] + " ";
                }
                display += Environment.NewLine;
            }


            return display;


        }
        //placing units in different teams

        //private void placeGMeleeUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "GM";

        //}
        //private void placeGRangeUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "GR";

        //}
        //private void placeGHealerUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "GH";

        //}
        //private void placeGMageUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "GM";

        //}
        //private void placeGThiefUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "GT";

        //}
        //private void placeGSpyUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "GS";

        //}
        //private void placeGDevilUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "GD";

        //}
        //private void placeBMeleeUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "BM";

        //}
        //private void placeBRangeUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "BR";

        //}
        //private void placeBHealerUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "BH";

        //}
        //private void placeBMageUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "BM";

        //}
        //private void placeBThiefUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "BT";

        //}

        //private void placeBSpyUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "BS";

        //}
        //private void placeBDevilUnit(int xPosition, int yPosition)
        //{
        //    map[xPosition, yPosition] = "BD";

        //}


        private void moveUnit(Unit u, int newX, int newY)
        {

            map[u.X, u.Y] = FIELD_SYMBOL;
            map[newX, newY] = u.Symbol;

        }

        public void update(Unit u, int newX, int newY)
        {
            if ((newX >= 0 && newX < 20) && (newY >= 0 && newY < 20))
            {
                moveUnit(u, newX, newY);
                u.move(newX, newY);

            }

        }

        public void checkHealth()
        {
            for (int i = 0; i < numberOfUnitsOnMap; i++)
            {
                if (!unitsOnMap[i].isAlive())
                {
                    map[unitsOnMap[i].X, unitsOnMap[i].Y] = FIELD_SYMBOL;
                    unitsOnMap[i] = null;
                    numberOfUnitsOnMap--;
                }
            }
        }
        public void generateUnits()
        {



            Random rnd = new Random();
            int numberOfUnits = rnd.Next(0, 25);
            int x, y;

            //blue team

            for (int i = 0; i < numberOfUnits; i++)
            {
                team();
                x = rnd.Next(0, 20);
                y = rnd.Next(0, 20);
                do
                {
                    x = rnd.Next(0, 20);
                    y = rnd.Next(0, 20);
                }
                while (map[x, y] != ".");

                MeleeUnit m = new MeleeUnit(x, y-20, 100, 2, true, 1, unitFaction, "M", "Foot Soldier");
                unitsOnMap.Add(m);

                map[x, y] = unitFaction + m.Symbol;
                //placeBMeleeUnit(x, y);
            }

            for (int i = 0; i < numberOfUnits; i++)
            {
                team();

                x = rnd.Next(0, 20);
                y = rnd.Next(0, 20);
                do
                {
                    x = rnd.Next(0, 20);
                    y = rnd.Next(0, 20);
                }
                while (map[x, y] != ".");

                RangedUnit r = new RangedUnit(x, y-20, 100, 3, true, 5, unitFaction, "R", "Archer");
                unitsOnMap.Add(r);

                map[x, y] = unitFaction + r.Symbol;

                //placeBRangeUnit(x, y);
            }
        }

        //    numberOfUnits = rnd.Next(0, 10);
        //    for (int i = 0; i < numberOfUnits; i++)
        //    {
        //        team();

            //        x = rnd.Next(0, 20);
            //        y = rnd.Next(0, 20);
            //        do
            //        {
            //            x = rnd.Next(0, 20);
            //            y = rnd.Next(0, 20);
            //        } while (map[x, y] != ".");

            //        HealerUnit h = new HealerUnit(x, y, 100, 2, true, 5, unitFaction, "H", "Healer");
            //        unitsOnMap.Add(h);

            //        map[x, y] = unitFaction + h.Symbol;

            //        //placeBHealerUnit(x, y);
            //    }

            //    numberOfUnits = rnd.Next(0, 10);
            //    for (int i = 0; i < numberOfUnits; i++)
            //    {
            //        team();

            //        x = rnd.Next(0, 20);
            //        y = rnd.Next(0, 20);
            //        do
            //        {
            //            x = rnd.Next(0, 20);
            //            y = rnd.Next(0, 20);
            //        } while (map[x, y] != ".");

            //        MageUnit mage = new MageUnit(x, y, 100, 2, true, 5, unitFaction, "W", "Wizard");
            //        unitsOnMap.Add(mage);

            //        map[x, y] = unitFaction + mage.Symbol;

            //        //placeBMageUnit(x, y);
            //    }

            //    numberOfUnits = 2;
            //    for (int i = 0; i < numberOfUnits; i++)
            //    {
            //        team();

            //        x = rnd.Next(0, 20);
            //        y = rnd.Next(0, 20);
            //        do
            //        {
            //            x = rnd.Next(0, 20);
            //            y = rnd.Next(0, 20);
            //        } while (map[x, y] != ".");

            //        ThiefUnit t = new ThiefUnit(x, y, 100, 8, true, 2, unitFaction, "T", "Healer");
            //        unitsOnMap.Add(t);

            //        map[x, y] = unitFaction + t.Symbol;

            //        //placeBThiefUnit(x, y);
            //    }

            //    numberOfUnits = rnd.Next(0, 5);
            //    for (int i = 0; i < numberOfUnits; i++)
            //    {
            //        team();

            //        x = rnd.Next(0, 20);
            //        y = rnd.Next(0, 20);
            //        do
            //        {
            //            x = rnd.Next(0, 20);
            //            y = rnd.Next(0, 20);
            //        } while (map[x, y] != ".");

            //        SpyUnit s = new SpyUnit(x, y, 100, 8, true, 2, unitFaction, "S", "Spy");
            //        unitsOnMap.Add(s);

            //        map[x, y] = unitFaction + s.Symbol;

            //        //placeBSpyUnit(x, y);
            //    }

            //    numberOfUnits = 2;
            //    for (int i = 0; i < numberOfUnits; i++)
            //    {
            //        team();

            //        x = rnd.Next(0, 20);
            //        y = rnd.Next(0, 20);
            //        do
            //        {
            //            x = rnd.Next(0, 20);
            //            y = rnd.Next(0, 20);
            //        } while (map[x, y] != ".");

            //        DevilUnit d = new DevilUnit(x, y, 100, 4, true, 1, unitFaction, "D", "Devil");
            //        unitsOnMap.Add(d);

            //        map[x, y] = unitFaction + d.Symbol;


            //        //placeBDevilUnit(x, y);
            //    }
            //    numberOfUnits = numberOfUnitsOnMap;
            ////green team

            //numberOfUnits = rnd.Next(0, 25);


            //for (int i = 0; i < numberOfUnits; i++)
            //{
            //    x = rnd.Next(0, 20);
            //    y = rnd.Next(0, 20);
            //    do
            //    {
            //        x = rnd.Next(0, 20);
            //        y = rnd.Next(0, 20);
            //    } while (map[x, y] != ".");


            //    mU[i] = new MeleeUnit(x, y, 100, 2, true, 1, "B", "GM", "Foot Soldier");
            //    map[x, y] = mU[i].Symbol;

            //    //placeGMeleeUnit(x, y);
            //}


            //numberOfUnits = rnd.Next(0, 25);


            //for (int i = 0; i < numberOfUnits; i++)
            //{
            //    x = rnd.Next(0, 20);
            //    y = rnd.Next(0, 20);
            //    do
            //    {
            //        x = rnd.Next(0, 20);
            //        y = rnd.Next(0, 20);
            //    } while (map[x, y] != ".");

            //    rU[i] = new RangedUnit(x, y, 100, 3, true, 5, "G", "GR", "Archer");
            //    map[x, y] =rU[i].Symbol;

            //    //placeGRangeUnit(x, y);
            //}

            //numberOfUnits = rnd.Next(0, 10);
            //for (int i = 0; i < numberOfUnits; i++)
            //{
            //    x = rnd.Next(0, 20);
            //    y = rnd.Next(0, 20);
            //    do
            //    {
            //        x = rnd.Next(0, 20);
            //        y = rnd.Next(0, 20);
            //    } while (map[x, y] != ".");

            //    hU[i] = new HealerUnit(x, y, 100, 5, true, 5, "G", "GH", "Healer");
            //    map[x, y] = hU[i].Symbol;

            //    //placeGHealerUnit(x, y);

            //}
            //numberOfUnits = rnd.Next(0, 10);
            //for (int i = 0; i < numberOfUnits; i++)
            //{
            //    x = rnd.Next(0, 20);
            //    y = rnd.Next(0, 20);
            //    do
            //    {
            //        x = rnd.Next(0, 20);
            //        y = rnd.Next(0, 20);
            //    } while (map[x, y] != ".");

            //    mageU[i] = new MageUnit(x, y, 100, 2, true, 5, "G", "GM", "Mage");
            //    map[x, y] = mageU[i].Symbol;

            //    //placeGMageUnit(x, y);
            //}

            //numberOfUnits = 1;
            //for (int i = 0; i < numberOfUnits; i++)
            //{
            //    x = rnd.Next(0, 20);
            //    y = rnd.Next(0, 20);
            //    do
            //    {
            //        x = rnd.Next(0, 20);
            //        y = rnd.Next(0, 20);
            //    } while (map[x, y] != ".");

            //    thiefU[i] = new ThiefUnit(x, y, 100, 5, true, 1, "G", "GT", "Thief");
            //    map[x, y] = thiefU[i].Symbol;

            //    //placeGThiefUnit(x, y);
            //}

            //numberOfUnits = rnd.Next(0, 5);
            //for (int i = 0; i < numberOfUnits; i++)
            //{
            //    x = rnd.Next(0, 20);
            //    y = rnd.Next(0, 20);
            //    do
            //    {
            //        x = rnd.Next(0, 20);
            //        y = rnd.Next(0, 20);
            //    } while (map[x, y] != ".");

            //    sU[i] = new SpyUnit(x, y, 100, 2, true, 5, "G", "GS", "Spy");
            //    map[x, y] = sU[i].Symbol;

            //    //placeBSpyUnit(x, y);
            //}

            //numberOfUnits = 1;
            //for (int i = 0; i < numberOfUnits; i++)
            //{
            //    x = rnd.Next(0, 20);
            //    y = rnd.Next(0, 20);
            //    do
            //    {
            //        x = rnd.Next(0, 20);
            //        y = rnd.Next(0, 20);
            //    } while (map[x, y] != ".");

            //    dU[i] = new DevilUnit(x, y, 100, 10, true, 15, "B", "GD", "DEVIL");
            //    map[x, y] = dU[i].Symbol;

            //    //placeGDevilUnit(x, y);
            //}


            //}





            #region read
            //reading from a file
        private List<MeleeUnit> meleeList = new List<MeleeUnit>();
        private List<MeleeUnit> MeleeList
        {
            get { return meleeList; }
        }

        private List<RangedUnit> rangedList = new List<RangedUnit>();
        private List<RangedUnit> RangedList
        {
            get { return rangedList; }
        }

        private List<FactoryBuilding> factoryList = new List<FactoryBuilding>();
        private List<FactoryBuilding> FactoryBuilding
        {
            get { return factoryList; }
        }

        private List<ResourceBuilding> resourceList = new List<ResourceBuilding>();
        private List<ResourceBuilding> ResourceList

        {
            get { return resourceList; }
        }

        public void loadMap()
        {

            FileStream inFile = null;
            StreamReader reader = null;
            string input;
            int x;
            int y;
            int health;
            int speed;
            bool attack;
            int attackRange;
            string faction;
            string symbol;
            string name;
            string resourceType;
            int resourcesPerTick;
            int resourcesRemaining;

            try
            {
                inFile = new FileStream(@"Files\meleeunit.txt", FileMode.Open, FileAccess.Read);
                reader = new StreamReader(inFile);
                input = reader.ReadLine();      // priming read
                while (input != null)
                {
                    x = int.Parse(reader.ReadLine());
                    y = int.Parse(reader.ReadLine());
                    health = int.Parse(reader.ReadLine());
                    speed = int.Parse(reader.ReadLine());
                    attack = bool.Parse(reader.ReadLine());
                    attackRange = int.Parse(reader.ReadLine());
                    faction = reader.ReadLine();
                    symbol = reader.ReadLine();
                    name = reader.ReadLine();

                    MeleeUnit m = new MeleeUnit(x, y, health, speed, attack, attackRange, faction, symbol, name);
                    meleeList.Add(m);
                    input = reader.ReadLine();      // secondary read
                }
                reader.Close();
                inFile.Close();
            }
            catch (Exception fe)
            {
                Debug.WriteLine(fe.Message);
            }
            finally
            {
                if (inFile != null)
                {
                    reader.Close();
                    inFile.Close();
                }
            }


            try
            {
                inFile = new FileStream(@"Files\rangedunit.txt", FileMode.Open, FileAccess.Read);
                reader = new StreamReader(inFile);
                input = reader.ReadLine();      // priming read
                while (input != null)
                {
                    x = int.Parse(reader.ReadLine());
                    y = int.Parse(reader.ReadLine());
                    health = int.Parse(reader.ReadLine());
                    speed = int.Parse(reader.ReadLine());
                    attack = bool.Parse(reader.ReadLine());
                    attackRange = int.Parse(reader.ReadLine());
                    faction = reader.ReadLine();
                    symbol = reader.ReadLine();
                    name = reader.ReadLine();

                    RangedUnit r = new RangedUnit(x, y, health, speed, attack, attackRange, faction, symbol, name);
                    rangedList.Add(r);
                    input = reader.ReadLine();      // secondary read
                }
                reader.Close();
                inFile.Close();
            }
            catch (Exception fe)
            {
                Debug.WriteLine(fe.Message);
            }
            finally
            {
                if (inFile != null)
                {
                    reader.Close();
                    inFile.Close();
                }
            }

            try
            {
                inFile = new FileStream(@"Files\factorybuilding.txt", FileMode.Open, FileAccess.Read);
                reader = new StreamReader(inFile);
                input = reader.ReadLine();      // priming read
                while (input != null)
                {
                    x = int.Parse(reader.ReadLine());
                    y = int.Parse(reader.ReadLine());
                    health = int.Parse(reader.ReadLine());
                    faction = reader.ReadLine();
                    symbol = reader.ReadLine();

                    FactoryBuilding f = new FactoryBuilding(x, y, health, faction, symbol);
                    factoryList.Add(f);
                    input = reader.ReadLine();      // secondary read
                }
                reader.Close();
                inFile.Close();
            }
            catch (Exception fe)
            {
                Debug.WriteLine(fe.Message);
            }
            finally
            {
                if (inFile != null)
                {
                    reader.Close();
                    inFile.Close();
                }
            }

            try
            {
                inFile = new FileStream(@"Files\resourcebuilding.txt", FileMode.Open, FileAccess.Read);
                reader = new StreamReader(inFile);
                input = reader.ReadLine();      // priming read
                while (input != null)
                {
                    x = int.Parse(reader.ReadLine());
                    y = int.Parse(reader.ReadLine());
                    health = int.Parse(reader.ReadLine());
                    faction = reader.ReadLine();
                    symbol = reader.ReadLine();
                    resourceType = reader.ReadLine();
                    resourcesPerTick = int.Parse(reader.ReadLine());
                    resourcesRemaining = int.Parse(reader.ReadLine());


                    ResourceBuilding rb = new ResourceBuilding(x, y, health, faction, symbol, resourceType, resourcesPerTick, resourcesRemaining);
                    resourceList.Add(rb);
                    input = reader.ReadLine();      // secondary read
                }
                reader.Close();
                inFile.Close();
            }
            catch (Exception fe)
            {
                Debug.WriteLine(fe.Message);
            }
            finally
            {
                if (inFile != null)
                {
                    reader.Close();
                    inFile.Close();
                }
            }

        }


        #endregion

        //public void (MeleeUnit, int x, int y)
        //{
        //    mU.X = x;
        //    meleeUnit.Y = y;
        //}

        //public void update(Map.mU)
        //{
        //    map[uRange.X, uRange.Y] = ".";
        //    position(mU, new X, new Y);
        //    map[mU.X, M.Y] = ".";
        //}
    }

}

