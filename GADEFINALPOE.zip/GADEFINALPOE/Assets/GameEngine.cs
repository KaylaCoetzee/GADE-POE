﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GADEFINALPOE
{
    public class GameEngine : MonoBehaviour
    {
        public int height;
        public int width;
        private Map map = new Map();

        // Use this for initialization
        void Start()
        {
            //draw

            int xStart = 19;
            int yStart = 19;
            var tileSize = new Vector2(2, 2);



            for (int k = 0; k < height; k++)
            {
                var yPos = -k * tileSize.y + yStart;
                for (int i = 0; i < width; i++)
                {
                    var xPos = i * tileSize.x - xStart;
                    Instantiate(Resources.Load("Tile"), new Vector3(xPos, yPos, 0), Quaternion.identity);
                }
            }
            map.initialiseMap();
            map.generateUnits();

            Debug.Log("Number of Units: " + map.numberOfUnitsOnMap.ToString());
            foreach (Unit temp in map.unitsOnMap)
            {
                if (temp != null)
                {
                    var unitType = temp.GetType().ToString();
                    var xPos = temp.X * tileSize.x - xStart;
                    var yPos = temp.Y * tileSize.y + yStart;

                    if (unitType.Contains("MeleeUnit"))
                    {
                        if (temp.Faction.Equals("B"))
                        {
                            Instantiate(Resources.Load("FootSoldierB"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                        }
                        else
                        {
                            Instantiate(Resources.Load("FootSoldierO"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                        }
                    }
                    else if (unitType.Contains("RangedUnit"))
                    {
                        if (temp.Faction.Equals("B"))
                        {
                            Instantiate(Resources.Load("ArcherB"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                        }
                        else
                        {
                            Instantiate(Resources.Load("ArcherO"), new Vector3(xPos, yPos, -2), Quaternion.identity);

                        }
                    }

                }
            }
            foreach (Building temp in map.buildingsOnMap)
            {
                if (temp != null)
                {
                    var buildingType = temp.GetType().ToString();
                    var xPos = temp.X * tileSize.x - xStart;
                    var yPos = temp.Y * tileSize.y + yStart;

                    if (buildingType.Contains("FactoryBuilding"))
                    {
                        if (temp.Faction.Equals("Orange"))
                        {
                            Instantiate(Resources.Load("FactoryB"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                        }
                        else
                        {
                            Instantiate(Resources.Load("FactoryB"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                        }
                    }
                    else if (buildingType.Contains("ResourceBuilding"))
                    {
                        if (temp.Faction.Equals("Blue"))
                        {
                            Instantiate(Resources.Load("ResourceB"), new Vector3(xPos, yPos, -2), Quaternion.identity);
                        }
                        else
                        {
                            Instantiate(Resources.Load("ResourceB"), new Vector3(xPos, yPos, -2), Quaternion.identity);

                        }
                    }

                }
            }
        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}



